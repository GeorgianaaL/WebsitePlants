<?php 

$con=mysqli_connect('localhost','root','','plants');
if(!$con){
    die(mysqli_error($con));
}

?>