
<div class="contact p-3 text-light text-center">
    <p>Contact</p>
    <p>Telefon: 0701 977 889</p>
    <p>Email: green_living@gmail.com</p>
    <p>Program: 9 - 20</p>
    <p>Green Living GL @ 2022</p>
</div>

